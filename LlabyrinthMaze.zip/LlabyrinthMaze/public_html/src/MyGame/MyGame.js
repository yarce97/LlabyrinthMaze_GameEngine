/*
 * File: MyGame.js 
 * This is the logic of our game. 
 */

/*jslint node: true, vars: true */
/*global gEngine, Scene, GameObjectset, TextureObject, Camera, vec2,
  FontRenderable, SpriteRenderable, LineRenderable,
  GameObject */
/* find out more about jslint: http://www.jslint.com/help.html */

"use strict";  // Operate in Strict mode such that variables must be declared before used!

function MyGame() {

    this.kMaze_sprite = "assets/maze_sprite.png";
    
    // The camera to view the scene
    this.mCamera = null;

    this.mAllFire = null;
    
    this.mLever = null;
    this.mButton = null;
    this.mExit = null;

}
gEngine.Core.inheritPrototype(MyGame, Scene);


MyGame.prototype.loadScene = function () {
    gEngine.Textures.loadTexture(this.kMaze_sprite);
};

MyGame.prototype.unloadScene = function () {
    gEngine.Textures.loadTexture(this.kMaze_sprite);
};

MyGame.prototype.initialize = function () {
    // Step A: set up the cameras
    this.mCamera = new Camera(
        vec2.fromValues(50, 40), // position of the camera
        100,                     // width of camera
        [0, 0, 800, 600]         // viewport (orgX, orgY, width, height)
    );
    this.mCamera.setBackgroundColor([0.8, 0.8, 0.8, 1]);
            // sets the background to gray
    gEngine.DefaultResources.setGlobalAmbientIntensity(3);
    
   // this.mPlatforms = new GameObjectSet();
    this.mAllFire = new GameObjectSet();
    
    this.mLever = new Lever(this.kMaze_sprite);
    this.mButton = new Button(this.kMaze_sprite);
    this.mExit = new Exit(this.kMaze_sprite);
   // this.createBounds();
//    var m;
//    m=new Fire(35,13,3,36,8,0,0,2,15,0,2.5,1);
//    this.mAllFire.addToSet(m);

};

// This is the draw function, make sure to setup proper drawing environment, and more
// importantly, make sure to _NOT_ change any state.
MyGame.prototype.draw = function () {
    // Step A: clear the canvas
    gEngine.Core.clearCanvas([0.9, 0.9, 0.9, 1.0]); // clear to light gray

    this.mCamera.setupViewProjection();
    this.mLever.draw(this.mCamera);
    this.mButton.draw(this.mCamera);
    this.mExit.draw(this.mCamera);
    
  //  this.mAllFire.draw(this.mCamera);
   
};

// The Update function, updates the application state. Make sure to _NOT_ draw
// anything from this function!
MyGame.kBoundDelta = 0.1;
MyGame.prototype.update = function () {
//    gEngine.ParticleSystem.update(this.mAllFire);
//    if (gEngine.Input.isKeyClicked(gEngine.Input.keys.Left)) {
//        var fire = this.mAllFire.getObjectAt(0);
//        var pos = fire.getPos();
//        fire.setPos(pos[0]+1, pos[1]);
//    } 
this.mLever.update();
this.mButton.update(this.mCamera);
    

};
