/* File: Hero.js 
 *
 * Creates and initializes the Hero (Dye)
 * overrides the update function of GameObject to define
 * simple Dye behavior
 */

/*jslint node: true, vars: true */
/*global gEngine, GameObject, LightRenderable, SpriteAnimateRenderable, vec2,NonPhysicsGameObject */
/* find out more about jslint: http://www.jslint.com/help.html */

"use strict";  // Operate in Strict mode such that variables must be declared before used!
//+128 px
function Button(spriteTexture) {
    
    this.mButton = new SpriteAnimateRenderable(spriteTexture);
    this.mButton.setColor([1, 1, 1, 0]);
    this.mButton.getXform().setPosition(70, 45);
    this.mButton.getXform().setSize(8, 8);
    this.mButton.setElementPixelPositions(0, 128, 384, 512);  
    this.posNoPush = [0, 128, 384, 512];
    this.posPush = [128, 256, 384, 512];
  
    GameObject.call(this, this.mButton);
    
}
gEngine.Core.inheritPrototype(Button, GameObject);


Button.prototype.pushButtom = function() {

    this.mButton.setElementPixelPositions(128, 256, 384, 512);  
};

Button.prototype.resetButton = function() {
    this.mButton.setElementPixelPositions(0, 128, 384, 512);  
};
Button.prototype.update = function() {
    if (gEngine.Input.isKeyClicked(gEngine.Input.keys.Up)) {
        this.pushButtom()();
    } 
    if (gEngine.Input.isKeyClicked(gEngine.Input.keys.Down)) {
        this.resetButton()();
    } 
 
};



Button.prototype.draw = function(aCamera) {
    this.mButton.draw(aCamera);
};


